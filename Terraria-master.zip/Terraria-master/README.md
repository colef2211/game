Terraria 1.3.5.3
=====

This repo contains the decompiled source of the Terraria client and server binaries, from version 1.3.5.3. Decompiled with [JetBrains dotPeek](https://www.jetbrains.com/decompiler/). 

**Use this at your own risk:** I am not responsible for any legal consequences that may occur by using this decompiled code, nor will I provide support for it.
I am just providing the decompiled code as a reference and making it easily accessible on GitHub.

This repo does not include the game content.
If you want the content, buy the game on Steam.
