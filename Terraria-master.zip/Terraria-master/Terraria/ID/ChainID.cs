﻿// Decompiled with JetBrains decompiler
// Type: Terraria.ID.ChainID
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

namespace Terraria.ID
{
  public static class ChainID
  {
    public const short TendonHook = 0;
    public const short ThornHook = 1;
    public const short IlluminantHook = 2;
    public const short Wormhook = 3;
    public const short SilkRope = 4;
    public const short SilkRope2 = 5;
    public const short WebRope = 6;
    public const short WebRope2 = 7;
    public const short LunarSolar = 8;
    public const short LunarVortex = 9;
    public const short LunarNebula = 10;
    public const short LunarStardust = 11;
    public const short LunarSolarGlow = 12;
    public const short LunarVortexGlow = 13;
    public const short LunarNebulaGlow = 14;
    public const short LunarStardustGlow = 15;
    public const short StaticHook = 16;
    public const short Count = 17;
  }
}
