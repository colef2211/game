﻿// Decompiled with JetBrains decompiler
// Type: Terraria.ID.AmmoID
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

namespace Terraria.ID
{
  public static class AmmoID
  {
    public static int None = 0;
    public static int Gel = 23;
    public static int Arrow = 40;
    public static int Coin = 71;
    public static int FallenStar = 75;
    public static int Bullet = 97;
    public static int Sand = 169;
    public static int Dart = 283;
    public static int Rocket = 771;
    public static int Solution = 780;
    public static int Flare = 931;
    public static int Snowball = 949;
    public static int StyngerBolt = 1261;
    public static int CandyCorn = 1783;
    public static int JackOLantern = 1785;
    public static int Stake = 1836;
    public static int NailFriendly = 3108;
  }
}
