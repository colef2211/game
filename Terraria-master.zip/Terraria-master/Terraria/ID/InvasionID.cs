﻿// Decompiled with JetBrains decompiler
// Type: Terraria.ID.InvasionID
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

namespace Terraria.ID
{
  public static class InvasionID
  {
    public const short CachedInvasions = 3;
    public const short CachedFrostMoon = 1;
    public const short CachedPumpkinMoon = 2;
    public const short CachedOldOnesArmy = 3;
    public const short None = 0;
    public const short GoblinArmy = 1;
    public const short SnowLegion = 2;
    public const short PirateInvasion = 3;
    public const short MartianMadness = 4;
    public const short Count = 5;
  }
}
