﻿// Decompiled with JetBrains decompiler
// Type: Terraria.ID.RecipeGroupID
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

namespace Terraria.ID
{
  public class RecipeGroupID
  {
    public static int Birds = 0;
    public static int Scorpions = 1;
    public static int Bugs = 2;
    public static int Ducks = 3;
    public static int Squirrels = 4;
    public static int Butterflies = 5;
    public static int Fireflies = 6;
    public static int Snails = 7;
  }
}
