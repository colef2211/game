﻿// Decompiled with JetBrains decompiler
// Type: Terraria.ID.StatusID
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

namespace Terraria.ID
{
  public class StatusID
  {
    public const int Ok = 0;
    public const int LaterVersion = 1;
    public const int UnknownError = 2;
    public const int EmptyFile = 3;
    public const int DecryptionError = 4;
    public const int BadSectionPointer = 5;
    public const int BadFooter = 6;
  }
}
