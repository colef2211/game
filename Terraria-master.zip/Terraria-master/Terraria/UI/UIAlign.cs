﻿// Decompiled with JetBrains decompiler
// Type: Terraria.UI.UIAlign
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

namespace Terraria.UI
{
  public static class UIAlign
  {
    public const float Left = 0.0f;
    public const float Center = 0.5f;
    public const float Right = 1f;
    public const float Top = 0.0f;
    public const float Middle = 0.5f;
    public const float Bottom = 1f;
  }
}
