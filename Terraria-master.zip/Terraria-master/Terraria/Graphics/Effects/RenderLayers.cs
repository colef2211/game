﻿// Decompiled with JetBrains decompiler
// Type: Terraria.Graphics.Effects.RenderLayers
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

namespace Terraria.Graphics.Effects
{
  public enum RenderLayers
  {
    Sky,
    Landscape,
    Background,
    InWorldUI,
    BackgroundWater,
    Walls,
    TilesAndNPCs,
    Entities,
    ForegroundWater,
    All,
  }
}
