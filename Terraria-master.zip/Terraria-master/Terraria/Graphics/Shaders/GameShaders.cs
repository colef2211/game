﻿// Decompiled with JetBrains decompiler
// Type: Terraria.Graphics.Shaders.GameShaders
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

using System.Collections.Generic;

namespace Terraria.Graphics.Shaders
{
  public class GameShaders
  {
    public static ArmorShaderDataSet Armor = new ArmorShaderDataSet();
    public static HairShaderDataSet Hair = new HairShaderDataSet();
    public static Dictionary<string, MiscShaderData> Misc = new Dictionary<string, MiscShaderData>();
  }
}
