﻿// Decompiled with JetBrains decompiler
// Type: Terraria.Net.Sockets.SocketReceiveCallback
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

namespace Terraria.Net.Sockets
{
  public delegate void SocketReceiveCallback(object state, int size);
}
