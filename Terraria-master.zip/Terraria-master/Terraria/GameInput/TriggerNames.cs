﻿// Decompiled with JetBrains decompiler
// Type: Terraria.GameInput.TriggerNames
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

namespace Terraria.GameInput
{
  public class TriggerNames
  {
    public const string MouseLeft = "MouseLeft";
    public const string MouseRight = "MouseRight";
    public const string Up = "Up";
    public const string Down = "Down";
    public const string Left = "Left";
    public const string Right = "Right";
    public const string Jump = "Jump";
    public const string Throw = "Throw";
    public const string Inventory = "Inventory";
    public const string Grapple = "Grapple";
    public const string SmartSelect = "SmartSelect";
    public const string SmartCursor = "SmartCursor";
    public const string QuickMount = "QuickMount";
    public const string QuickHeal = "QuickHeal";
    public const string QuickMana = "QuickMana";
    public const string QuickBuff = "QuickBuff";
    public const string MapZoomIn = "MapZoomIn";
    public const string MapZoomOut = "MapZoomOut";
    public const string MapAlphaUp = "MapAlphaUp";
    public const string MapAlphaDown = "MapAlphaDown";
    public const string MapFull = "MapFull";
    public const string MapStyle = "MapStyle";
    public const string Hotbar1 = "Hotbar1";
    public const string Hotbar2 = "Hotbar2";
    public const string Hotbar3 = "Hotbar3";
    public const string Hotbar4 = "Hotbar4";
    public const string Hotbar5 = "Hotbar5";
    public const string Hotbar6 = "Hotbar6";
    public const string Hotbar7 = "Hotbar7";
    public const string Hotbar8 = "Hotbar8";
    public const string Hotbar9 = "Hotbar9";
    public const string Hotbar10 = "Hotbar10";
    public const string HotbarMinus = "HotbarMinus";
    public const string HotbarPlus = "HotbarPlus";
    public const string DpadRadial1 = "DpadRadial1";
    public const string DpadRadial2 = "DpadRadial2";
    public const string DpadRadial3 = "DpadRadial3";
    public const string DpadRadial4 = "DpadRadial4";
    public const string DpadMouseSnap1 = "DpadSnap1";
    public const string DpadMouseSnap2 = "DpadSnap2";
    public const string DpadMouseSnap3 = "DpadSnap3";
    public const string DpadMouseSnap4 = "DpadSnap4";
    public const string MenuUp = "MenuUp";
    public const string MenuDown = "MenuDown";
    public const string MenuLeft = "MenuLeft";
    public const string MenuRight = "MenuRight";
    public const string RadialHotbar = "RadialHotbar";
    public const string RadialQuickbar = "RadialQuickbar";
    public const string LockOn = "LockOn";
    public const string ViewZoomIn = "ViewZoomIn";
    public const string ViewZoomOut = "ViewZoomOut";
  }
}
