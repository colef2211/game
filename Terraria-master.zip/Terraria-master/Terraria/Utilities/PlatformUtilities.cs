﻿// Decompiled with JetBrains decompiler
// Type: Terraria.Utilities.PlatformUtilities
// Assembly: Terraria, Version=1.3.5.3, Culture=neutral, PublicKeyToken=null
// MVID: 68659D26-2BE6-448F-8663-74FA559E6F08
// Assembly location: H:\Steam\steamapps\common\Terraria\Terraria.exe

namespace Terraria.Utilities
{
  public static class PlatformUtilities
  {
    public const bool IsXNA = true;
    public const bool IsFNA = false;
    public const bool IsWindows = true;
    public const bool IsOSX = false;
    public const bool IsLinux = false;
  }
}
